#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <cmath>
#include <chrono>

struct Portfolio {
    double initial_price;
    double volatility;
    double drift;
    double horizon_years;
};

void run_monte_carlo_simulation(const Portfolio& pf, int num_simulations) {
    std::cout << "--- LANCEMENT DE LA SIMULATION MONTE CARLO VaR ---" << std::endl;
    std::cout << "Nombre de trajectoires simulees : " << num_simulations << std::endl;

    auto start_time = std::chrono::high_resolution_clock::now();

    std::vector<double> final_prices;
    final_prices.reserve(num_simulations);

    std::random_device rd;
    std::mt19937 generator(rd());
    std::normal_distribution<double> distribution(0.0, 1.0);

    double dt = pf.horizon_years;
    double sqrt_dt = std::sqrt(dt);
    double expected_return = (pf.drift - 0.5 * pf.volatility * pf.volatility) * dt;

    for (int i = 0; i < num_simulations; ++i) {
        double z = distribution(generator);
        double simulated_price = pf.initial_price * std::exp(expected_return + pf.volatility * sqrt_dt * z);
        final_prices.push_back(simulated_price);
    }

    std::sort(final_prices.begin(), final_prices.end());

    int index_95 = static_cast<int>(num_simulations * 0.05);
    int index_99 = static_cast<int>(num_simulations * 0.01);

    double var_95 = pf.initial_price - final_prices[index_95];
    double var_99 = pf.initial_price - final_prices[index_99];

    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end_time - start_time;

    std::cout << "--------------------------------------------------" << std::endl;
    std::cout << "[SUCCES] Simulation terminee en " << elapsed.count() << " secondes." << std::endl;
    std::cout << "Prix initial de l'actif : " << pf.initial_price << " EUR" << std::endl;
    std::cout << "VaR 95% (Horizon 1 an)  : Perte maximale de " << var_95 << " EUR" << std::endl;
    std::cout << "VaR 99% (Horizon 1 an)  : Perte maximale de " << var_99 << " EUR" << std::endl;
}

int main() {
    std::cout << "MONTE CARLO VaR ENGINE v1.0 (C++ Core)" << std::endl;

    Portfolio my_portfolio = {
        100.0,  
        0.25,   
        0.05,   
        1.0     
    };

    run_monte_carlo_simulation(my_portfolio, 100000);

    std::cout << "\nAppuyez sur une touche pour quitter..." << std::endl;
    std::system("pause");
    return 0;
}